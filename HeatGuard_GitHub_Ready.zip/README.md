# HeatGuard — GitHub-ready web app

## Files
- `index.html` — HeatGuard application
- `manifest.json` — installable web-app metadata
- `sw.js` — service worker for the app shell/offline fallback
- `icons/heatguard.svg` — app icon

## Publish with GitHub Pages
1. Create a new GitHub repository.
2. Upload **all files and the `icons` folder**, keeping this folder structure.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Open the Pages URL GitHub provides. Use HTTPS for PWA installation.

## Important: AI chatbot backend
The HTML calls `POST /api/heatguard-chat`. GitHub Pages is static hosting and cannot run that API route. The rest of the app can be hosted as a static site, but the AI chatbot will need a backend deployment (for example, a Vercel serverless function) and its required environment variable. Do not put an AI provider secret/API key in `index.html` or commit it to GitHub.

If you deploy the frontend on GitHub Pages and the API on another host, update the chatbot fetch URL in `index.html` to the full backend URL and configure CORS on that backend. Alternatively, deploy the same repository on Vercel with the matching `/api/heatguard-chat` function.

## Notes
- Weather, geocoding and air-quality features call public third-party endpoints and therefore need an internet connection.
- Offline support is limited to the cached app shell; live data and AI responses require network access.
- Verify the third-party IMD endpoint and browser access in your deployment environment; the app includes fallback weather/data sources.
